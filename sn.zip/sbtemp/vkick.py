elif cmd.startswith("vkick"):
proses = text.split(" ")
tx = text.replace(proses[0] + " ", "")
ljoin = text.replace(proses[0] + " ljoin", "")
if "ljoin" == proses[1] or "ljoin" + ljoin == proses[1]:
    if "" == ljoin:
        ljoin = "1"
    l = int(ljoin)
    l -= 1
    hasil = countLexe(to, "ljoin", l)
    num = []
    for a in hasil:
        try:
            noobcoder.kickoutFromGroup(to, [a])
    noobcoder.findAndAddContactsByMid(a)
    noobcoder.inviteIntoGroup(to, [a])
    noobcoder.cancelGroupInvitation(to, [a])
    except:noobcoder.sendMessage(to, "Kick is banned, try laters.")
num = text.replace(proses[0] + " lcon", "")
if "lcon" == proses[1] or "lcon" + num == proses[1]:
    if "" == num:
        try:
            noobcoder.kickoutFromGroup(to, [Lexe["lscon"][1]])
    noobcoder.kickoutFromGroup(to, [Lexe["lscon"][1]])
    noobcoder.kickoutFromGroup(to, [Lexe["lscon"][1]])
    noobcoder.kickoutFromGroup(to, [Lexe["lscon"][1]])
    Lexe["lstatus"] = True
except:noobcoder.sendMessage(to, "Kick is banned, try laters.")
else:
if int(num) <= len(Lexe["lscon"]):
    try:
        noobcoder.kickoutFromGroup(to, Lexe["lscon"][1])
noobcoder.findAndAddContactsByMid([Lexe["lscon"][1]])
noobcoder.inviteIntoGroup(to, [Lexe["lscon"][1]])
noobcoder.cancelGroupInvitation(to, [Lexe["lscon"][1]])
Lexe["lstatus"] = True
except:noobcoder.sendMessage(to, "Kick is banned, try laters.")
else:noobcoder.sendMessage(to, "Last contacts are only {}".forma(len(Lexe["lscon"])))
else:
key = []
try:
    key = eval(msg.contentMetadata["MENTION"])
except:
    key = []
if key == []:
    return
else:
    key["MENTIONEES"][0]["M"]
    targets = []
    for x in key["MENTIONEES"]: targets.append(x["M"])
    for a in targets:
        try:
            noobcoder.kickoutFromGroup(to, [a]);
noobcoder.findAndAddContactsByMid(a)
noobcoder.inviteIntoGroup(to, [a])
noobcoder.cancelGroupInvitation(to, [a])
return
except:noobcoder.sendMessage(to, "Kick is banned, try laters.")

